#include <iostream>
#include <fstream>
namespace dheeraj {
using namespace std;
int count=0;
int l_count=0;
char* str;
stringstream temp;
//FILE *fp;
//fp = fopen("three_address.txt", "w");
ofstream myfile("example.txt");


string get_temp()
{	stringstream temp;
	temp<<++count;
	return string("t"+temp.str());
}

string get_lbl()
{	
	stringstream temp;
	temp<<++l_count;
	return("L"+temp.str());
}

string traverse (struct Node *node)
{
	
	if(node->type==E_START)
	{
		if(node->st.declarations)
		traverse(node->st.declarations);
		myfile<<"main "<<":"<<endl;
		myfile<<"BeginFunc "<<";"<<endl;
		if(node->st.body)
		traverse(node->st.body);	
		myfile<<"EndFunc "<<";" <<endl;
		return "NULL";
	}

	if(node->type==E_STATEMENT_LIST)
	{
		//printf("statements\n");
		if(node->sl.statement)
		traverse(node->sl.list);	
		if(node->sl.list)
		traverse(node->sl.statement);
		return "NULL";	
	}

	if(node->type==E_VARIABLE_DECLARATION)
	{
		if(node->vd.value)
		{
			string v_name = traverse(node->vd.name);
			string v_exp="NULL";
			v_exp= traverse(node->vd.value);
			myfile<<v_name<< "=" <<v_exp<<endl;
		}
		return "NULL";
	}

	if(node->type==E_OPERATOR)
	{
		//printf("operator\n");
		if(Operator_size(node->op)==2)
		{
			string first = traverse(node->op.operands[0]);
			string second = traverse(node->op.operands[1]);
			string result;
			//printf("hello\n");
			//printf("first: %s second: %s \n",first,second);
			if(strcmp(operator_from_yacc_id(node->op._operator), "=") == 0)
			{
				//printf("%s = %s\n",first,second);
				myfile<<first<<"="<<second<<endl;
				result = "NULL";
			}
			else
			{	
				result = get_temp();
				//printf("%s=%s %s %s\n",result,first,operator_from_yacc_id(node->op.operator),second);
				myfile<<result<<" = "<<first<<" "<<operator_from_yacc_id(node->op._operator)<<" "<<second<<endl;
			}
			return result;
		}
	    else if(Operator_size(node->op)==1)
		{
			//cout<<"hello"<<endl;
			string ret = traverse(node->op.operands[0]);
			cout<<"hello"<<endl;
			string temp =  get_temp();
			cout<<"hello"<<endl;
			myfile<<temp<<" = "<<"-"<<ret<<";"<<endl;
			return temp;
		}
		return "NULL";
	}

	if(node->type==E_CONSTANT)
	{
		//printf("constant\n");
		//string val;
		//sprintf(val, "%d", node->con.value);
	string tmp = get_temp();	
	myfile<<tmp<<" = "<<node->con.value<<endl; 
	return string(tmp);	
	}

	if(node->type==E_IDENTIFIER)
	{	//printf("identifier\n");
		return(node->id.name);
	}

	if(node->type==E_IF)
	{
		string cond;
		cond=traverse(node->_if.condition);
		string lbl1 = get_lbl();
		string lbl2 = get_lbl();

		myfile<<"IfZ "<<cond<<" Goto " <<lbl1 <<";"<<endl;
		traverse (node->_if.if_statement);
		
		if(If_size(node->_if)==2)
		myfile<<lbl1<<":"<<endl;

		if(If_size(node->_if)==3)
		{
			
			myfile<<"Goto "<<lbl2<<";"<<endl;
			myfile<<lbl1<<":"<<endl;
			traverse (node->_if.else_statement);
			myfile<<lbl2<<":"<<endl;
		}
		return "NULL";
	}

	if(node->type==E_KEYWORD)
	{
	string tmp = get_temp();	
	myfile<<tmp<<" = "<<node->key.name<<endl; 
	return string(tmp);
	}

	if(node->type==E_WHILE)
	{
		string cond;
		string lbl1,lbl2;
		lbl1=get_lbl();	
		lbl2=get_lbl();
		myfile<<lbl1<<":"<<endl;
		cond=traverse(node->wh.condition);
		myfile<<"IfZ "<<cond <<" Goto "<<lbl2<<";"<<endl;
		traverse(node->wh.statement);
		myfile<<"Goto "<<lbl1<<";"<<endl;
		myfile<<lbl2<<":"<<endl;
		return "NULL";	
	}

	if(node->type==E_FUNCTION_DECLARATION)
	{
		string fname=traverse(node->fd.name);
		myfile<<fname<<":"<<endl;
		myfile<<"BeginFunc "<<";"<<endl;
		if(node->fd.body) traverse(node->fd.body);
		myfile<<"EndFunc "<<";"<<endl;
		return "NULL";
	}

	if(node->type==E_RETURN)
	{
		string ret;
		ret=traverse(node->ret.value);
		myfile<<"return "<<ret<<";"<<endl;
		return "NULL";
	}

	if(node->type==E_FUNCTION_CALL)
	{
		string fname = traverse(node->fc.name);
		if(node->fc.parameters)
		traverse(node->fc.parameters);
		string temp = get_temp();
		myfile<<temp<<" = Lcall "<<fname<<";"<<endl;
		return temp;
	}

	if(node->type==E_PARAMETER_LIST)
	{
		string ret;

		if(node->pl.parameter)
		{
		ret=traverse(node->pl.parameter);
			myfile<<"Pushparam "<<ret<<";"<<endl;
		}

		if(node->pl.list)
		{
			ret=traverse(node->pl.list);
			if(node->pl.list->type!=E_PARAMETER_LIST)
							myfile<<"Pushparam "<<ret<<";"<<endl;
		}
		return "NULL";
	}
	if(node->type==E_PRINT)
	{
		string ret = traverse(node->pr.exp);
		myfile<<"Pushparam "<<ret<<";"<<endl;
		string temp = get_temp();
		myfile<<temp<<" = Lcall Print"<<";"<<endl;
	}

	if(node->type==E_INPUT)
	{
		string ret = traverse(node->in.exp);
		myfile<<"Pushparam "<<ret<<";"<<endl;
		string temp = get_temp();
		myfile<<temp<<" = Lcall Input"<<";"<<endl;
	}

	if (node->type==E_LITERAL)
	{
		string ret = get_temp();
		ret = string(node->lit.value);
		return ret;
	}
	return "NULL";
}
//myfile.close();
//fclose(fp);
}