#ifndef symbol_table_h
#define symbol_table_h
#include <cassert>
#include <cstdio>
#include <string>
#include <iostream>
#include <vector>
#include <string>
using namespace std;


class RedeclarationError {};
class TypeMismatchError {};
class UndefinedError {};

int find_scope(string);

void add_to_symbol_table(string, string, string);

std::vector<string>  get_entry_from_symbol_table(string);

void add_scope();

void remove_scope();
#endif