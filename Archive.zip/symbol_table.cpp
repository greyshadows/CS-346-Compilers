#include "symbol_table.h"

using namespace std;

class ScopeSymbolTable {
public:
	vector<string> identifier;
	vector<string> type;
	vector<string> className;
	bool has(string key) {
		for (std::vector<string>::iterator i = identifier.begin(); i != identifier.end(); ++i) {
			if (*i == key)
			{
				return true;
			}
		}

		return false;
	}

	void add(string _identifier, string _type, string _className) {
		identifier.push_back(_identifier);
		type.push_back(_type);
		className.push_back(_className);
	}
};

vector<ScopeSymbolTable> symbol_table;

int find_scope(string key) {	
	for (int i = symbol_table.size() -1; i >= 0; --i)
	{
		if (symbol_table[i].has(key)) {
			return i;
		}
	}

	return -1;
}

void add_to_symbol_table(string identifier, string type, string className) {
	cout << className << " :: " << identifier << " -> " << type << endl;
	if (symbol_table.back().has(identifier)) {
		// TODO: handle error
		throw new RedeclarationError;
	}
	symbol_table.back().add(identifier, type, className);
}

std::vector<string> get_entry_from_symbol_table(string identifier) {
	int scope = find_scope(identifier);
	if (scope < 0) throw new UndefinedError;
	int index = 0;
	for (; index < symbol_table[scope].identifier.size(); ++index) {
		if (symbol_table[scope].identifier[index] == identifier) {
			break;
		}
	}
	std::vector<string> touple;
	touple.push_back(symbol_table[scope].identifier[index]);
	touple.push_back(symbol_table[scope].type[index]);
	touple.push_back(symbol_table[scope].className[index]);
	return touple;
}

void add_scope() {
	ScopeSymbolTable *s = new ScopeSymbolTable;
	symbol_table.push_back(*s);
}

void remove_scope() {
	symbol_table.pop_back();
}

// Default scope


// int find_scope(char *a) {
// 	return find_scope(string(a));
// }

// void add_to_symbol_table(char *a, char *b, char *c) {
// 	add_to_symbol_table(string(a), string(b), string(c));
// }

/*
int main() {
	add_scope();
	try {
		add_to_symbol_table("a", "int", "variable");
	} catch(RedeclarationError *error) {
		printf("Can not declare variable\n");
	}
	assert(find_scope("a") == 0);
	add_scope();
	
	try {
		add_to_symbol_table("a", "int", "variable");
	} catch(RedeclarationError *error) {
		printf("Can not redeclare variable in different scope\n");
	}
	assert(find_scope("a") == 1);

	try {
		add_to_symbol_table("a", "int", "variable");
		assert(false);
	} catch(RedeclarationError *error) {
		assert(true);
	}

	return 0;
}
*/